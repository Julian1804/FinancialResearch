本轮补丁聚焦五件事：
1. 公司下拉框过滤 _system
2. Parse 页面明确显示：复杂页目前仅走 multimodal_stub，不会调用云端 AI
3. 新增一体化入库页：Parse -> Extract -> Metrics
4. 扩展标准化指标字典，并把来源区分为 primary_timeline / auxiliary_signal
5. Actuals 只允许主时序财报进入，辅助材料只保留为预测修正信号，不能写入实际值主表

注意：
- 本补丁保持向后兼容，但建议优先从新的 ingest 页面走主流程。
- 如果你后续真的接入多模态云模型，可在 vision_parser_service.py 中替换 stub。
