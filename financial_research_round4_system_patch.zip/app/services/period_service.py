import re
from typing import Dict, Optional

REPORT_TYPE_ORDER = {"Q1": 1, "H1": 2, "Q3": 3, "FY": 4, "AUX": 9, "UNKNOWN": 99}


def normalize_text(text: str) -> str:
    return "" if text is None else str(text).strip()


def _contains_any(text: str, keywords: list[str]) -> bool:
    return any(keyword in text for keyword in keywords)


def _normalize_for_match(text: str) -> str:
    text = normalize_text(text).lower()
    for ch in ["_", "-", "—", "–"]:
        text = text.replace(ch, " ")
    return text


def detect_fiscal_year(source_file: str, text: str) -> Optional[int]:
    combined = f"{normalize_text(source_file)}\n{normalize_text(text)[:30000]}"
    years = re.findall(r"(19\d{2}|20\d{2})", combined)
    if not years:
        return None
    file_years = re.findall(r"(19\d{2}|20\d{2})", normalize_text(source_file))
    return int(file_years[0]) if file_years else int(years[0])


def detect_report_type(source_file: str, text: str) -> str:
    combined = f"{_normalize_for_match(source_file)}\n{_normalize_for_match(text[:25000])}"
    h1_keywords = ["interim report", "interim results", "half year report", "half year results", "half-year report", "half-year results", "semi annual report", "semi annual results", "semi-annual report", "semi-annual results", "mid year report", "mid year results", "mid-year report", "mid-year results", "中期报告", "中期報告", "中报", "中報", "半年报", "半年報", "半年度报告", "半年度報告", "中期年报", "中期年報", "中期业绩", "中期業績", "半年度业绩", "半年度業績", "上半年业绩", "上半年業績", "中期业绩新闻稿", "中期業績新聞稿", "中期业绩公告", "中期業績公告"]
    if _contains_any(combined, h1_keywords):
        return "H1"
    q3_keywords = ["third quarterly report", "third quarter report", "third quarter results", "q3 results", "9m results", "nine months results", "nine-month results", "第三季度报告", "第三季度報告", "三季报", "三季報", "第三季度业绩", "第三季度業績", "前三季度业绩", "前三季度業績"]
    if _contains_any(combined, q3_keywords):
        return "Q3"
    q1_keywords = ["first quarterly report", "first quarter report", "first quarter results", "q1 results", "quarter 1 results", "第一季度报告", "第一季度報告", "一季报", "一季報", "第一季度业绩", "第一季度業績", "一季度业绩", "一季度業績"]
    if _contains_any(combined, q1_keywords):
        return "Q1"
    fy_keywords = ["annual report", "annual results", "final results", "full year results", "full-year results", "fy results", "year end results", "年度报告", "年度報告", "年报", "年報", "全年业绩", "全年業績", "年度业绩", "年度業績", "全年业绩新闻稿", "全年業績新聞稿", "全年业绩公告", "全年業績公告", "年度业绩公告", "年度業績公告"]
    if _contains_any(combined, fy_keywords):
        return "FY"
    if "quarterly report" in combined or "季度报告" in combined or "季度報告" in combined:
        return "UNKNOWN"
    return "UNKNOWN"


def detect_document_type(source_file: str, text: str, report_type: str) -> str:
    combined = f"{_normalize_for_match(source_file)}\n{_normalize_for_match(text[:30000])}"
    primary_financial_keywords = ["annual report", "interim report", "quarterly report", "first quarterly report", "third quarterly report", "half year report", "half-year report", "semi annual report", "semi-annual report", "mid year report", "年度报告", "年度報告", "中期报告", "中期報告", "中期年报", "中期年報", "半年度报告", "半年度報告", "季度报告", "季度報告", "第一季度报告", "第一季度報告", "第三季度报告", "第三季度報告", "年报", "年報", "中报", "中報", "半年报", "半年報", "一季报", "一季報", "三季报", "三季報"]
    if _contains_any(combined, primary_financial_keywords):
        return "financial_report"

    if report_type in {"Q1", "H1", "Q3", "FY"}:
        filename_only = _normalize_for_match(source_file)
        release_like = ["新闻稿", "新聞稿", "公告", "发布", "發布", "presentation", "investor", "conference call", "业绩说明", "業績說明", "电话会", "電話會"]
        if not _contains_any(filename_only, release_like) and any(k in filename_only for k in ["年报", "年報", "中报", "中報", "半年报", "半年報", "季报", "季報", "报告", "報告"]):
            return "financial_report"

    if _contains_any(combined, ["业绩预告", "盈喜", "盈警", "profit warning", "positive profit alert", "earnings preannouncement", "preliminary earnings estimate", "guidance update"]):
        return "earnings_preannouncement"
    if _contains_any(combined, ["业绩公告", "业绩发布", "业绩新聞稿", "业绩新闻稿", "results announcement", "results release", "earnings release", "news release", "annual results announcement", "interim results announcement", "quarterly results announcement", "全年业绩新闻稿", "全年業績新聞稿"]):
        return "earnings_release"
    if _contains_any(combined, ["业绩简报", "业绩说明", "业绩演示", "路演材料", "presentation", "results presentation", "earnings presentation", "investor presentation"]):
        return "earnings_presentation"
    if _contains_any(combined, ["投资者关系", "投资者交流", "投资者会议", "电话会议", "conference call", "investor communication", "investor call"]):
        return "investor_communication"
    if _contains_any(combined, ["经营数据", "运营数据", "operational update", "monthly operational"]):
        return "operational_update"
    if report_type in {"Q1", "H1", "Q3", "FY"}:
        return "financial_report"
    return "other_disclosure"


def build_period_key(fiscal_year: Optional[int], report_type: str) -> str:
    if not fiscal_year or report_type not in {"Q1", "H1", "Q3", "FY"}:
        return ""
    return f"{fiscal_year}{report_type}"


def is_annual_final(report_type: str) -> bool:
    return report_type == "FY"


def is_primary_financial_report(report_type: str, document_type: str) -> bool:
    return document_type == "financial_report" and report_type in {"Q1", "H1", "Q3", "FY"}


def can_adjust_forecast(report_type: str, document_type: str) -> bool:
    return is_primary_financial_report(report_type, document_type) or document_type in {"earnings_preannouncement", "earnings_release", "earnings_presentation", "investor_communication", "operational_update"}


def extract_report_date(text: str, source_file: str = "") -> str:
    combined = f"{normalize_text(source_file)}\n{normalize_text(text)[:30000]}"
    patterns = [r"(20\d{2}-\d{1,2}-\d{1,2})", r"(20\d{2}/\d{1,2}/\d{1,2})", r"(20\d{2}\.\d{1,2}\.\d{1,2})", r"(20\d{2}年\d{1,2}月\d{1,2}日)", r"(20\d{2}年\d{1,2}月)", r"(20\d{2}/\d{1,2})", r"(20\d{2}-\d{1,2})", r"(20\d{2}\.\d{1,2})", r"(20\d{2})"]
    for pattern in patterns:
        match = re.search(pattern, combined)
        if match:
            return match.group(1)
    return ""


def normalize_material_timestamp(date_text: str) -> Dict[str, str]:
    date_text = normalize_text(date_text)
    if not date_text:
        return {"material_timestamp": "", "material_timestamp_precision": "unknown"}
    date_text = date_text.replace("/", "-").replace(".", "-")
    m = re.fullmatch(r"(20\d{2})-(\d{1,2})-(\d{1,2})", date_text)
    if m:
        y, mm, dd = m.groups()
        return {"material_timestamp": f"{int(y):04d}-{int(mm):02d}-{int(dd):02d}", "material_timestamp_precision": "day"}
    m = re.fullmatch(r"(20\d{2})年(\d{1,2})月(\d{1,2})日", date_text)
    if m:
        y, mm, dd = m.groups()
        return {"material_timestamp": f"{int(y):04d}-{int(mm):02d}-{int(dd):02d}", "material_timestamp_precision": "day"}
    m = re.fullmatch(r"(20\d{2})-(\d{1,2})", date_text)
    if m:
        y, mm = m.groups()
        return {"material_timestamp": f"{int(y):04d}-{int(mm):02d}", "material_timestamp_precision": "month"}
    m = re.fullmatch(r"(20\d{2})年(\d{1,2})月", date_text)
    if m:
        y, mm = m.groups()
        return {"material_timestamp": f"{int(y):04d}-{int(mm):02d}", "material_timestamp_precision": "month"}
    m = re.fullmatch(r"(20\d{2})", date_text)
    if m:
        return {"material_timestamp": m.group(1), "material_timestamp_precision": "year"}
    return {"material_timestamp": date_text, "material_timestamp_precision": "raw"}


def infer_forecast_periods(fiscal_year: Optional[int], report_type: str, document_type: str, period_key: str, is_primary: bool) -> Dict[str, str]:
    forecast_as_of_period = ""
    forecast_target_period = ""
    if is_primary and period_key:
        forecast_as_of_period = period_key
        if fiscal_year and report_type in {"Q1", "H1", "Q3"}:
            forecast_target_period = f"{fiscal_year}FY"
        elif fiscal_year and report_type == "FY":
            forecast_target_period = f"{fiscal_year + 1}FY"
        return {"forecast_as_of_period": forecast_as_of_period, "forecast_target_period": forecast_target_period}
    if fiscal_year and document_type != "financial_report":
        forecast_as_of_period = f"{fiscal_year}AUX"
        if report_type in {"Q1", "H1", "Q3"}:
            forecast_target_period = f"{fiscal_year}FY"
        elif report_type == "FY":
            forecast_target_period = f"{fiscal_year + 1}FY"
        else:
            forecast_target_period = f"{fiscal_year}FY"
    return {"forecast_as_of_period": forecast_as_of_period, "forecast_target_period": forecast_target_period}


def build_period_metadata(source_file: str, text: str) -> Dict[str, object]:
    fiscal_year = detect_fiscal_year(source_file, text)
    report_type = detect_report_type(source_file, text)
    period_key = build_period_key(fiscal_year, report_type)
    document_type = detect_document_type(source_file, text, report_type)
    primary_flag = is_primary_financial_report(report_type, document_type)
    report_date = extract_report_date(text, source_file)
    timestamp_info = normalize_material_timestamp(report_date)
    forecast_periods = infer_forecast_periods(fiscal_year=fiscal_year, report_type=report_type, document_type=document_type, period_key=period_key, is_primary=primary_flag)
    related_primary_period_key = build_period_key(fiscal_year, report_type)
    return {
        "fiscal_year": fiscal_year if fiscal_year else None,
        "report_type": report_type,
        "period_key": period_key,
        "related_primary_period_key": related_primary_period_key,
        "document_type": document_type,
        "timeline_bucket": "primary" if primary_flag else "auxiliary",
        "report_date": report_date,
        "material_timestamp": timestamp_info["material_timestamp"],
        "material_timestamp_precision": timestamp_info["material_timestamp_precision"],
        "is_annual_final": is_annual_final(report_type),
        "is_primary_financial_report": primary_flag,
        "can_adjust_forecast": can_adjust_forecast(report_type, document_type),
        "forecast_as_of_period": forecast_periods["forecast_as_of_period"],
        "forecast_target_period": forecast_periods["forecast_target_period"],
    }


def period_sort_tuple(period_key: str):
    period_key = normalize_text(period_key)
    if not period_key:
        return (9999, REPORT_TYPE_ORDER["UNKNOWN"], period_key)
    m = re.fullmatch(r"(\d{4})(Q1|H1|Q3|FY|AUX)", period_key)
    if not m:
        return (9999, REPORT_TYPE_ORDER["UNKNOWN"], period_key)
    year, rpt = m.groups()
    return (int(year), REPORT_TYPE_ORDER.get(rpt, REPORT_TYPE_ORDER["UNKNOWN"]), period_key)
