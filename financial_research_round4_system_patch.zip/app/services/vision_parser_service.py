import os


def parse_page_with_multimodal_stub(
    image_path: str,
    fallback_text: str = "",
    page_number: int = 0
) -> dict:
    filename = os.path.basename(image_path) if image_path else ""

    if fallback_text and len(fallback_text.strip()) > 20:
        extracted_text = fallback_text
    else:
        extracted_text = (
            f"[多模态接口预留] 第 {page_number} 页当前被判定为复杂页面，"
            f"已保留页面图片：{filename}。后续可接入真实多模态模型进行 OCR、表格、图表解析。"
        )

    return {
        "engine": "multimodal_stub",
        "provider": "stub",
        "ai_called": False,
        "text": extracted_text,
        "raw_markdown": "",
        "table_blocks": [],
        "image_blocks": [],
        "notes": "当前为占位版多模态解析结果，尚未接入真实视觉模型，因此不会产生阿里云或 DeepSeek 调用记录。"
    }
