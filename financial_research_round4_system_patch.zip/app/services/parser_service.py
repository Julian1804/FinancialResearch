import os
import json
import re
import unicodedata
from collections import Counter

from pypdf import PdfReader
import fitz
import pdfplumber

from services.vision_parser_service import parse_page_with_multimodal_stub
from services.period_service import build_period_metadata
from utils.file_utils import build_page_images_folder


def normalize_text(text: str) -> str:
    if text is None:
        return ""

    text = str(text)
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\x00", " ")
    text = text.replace("\ufeff", " ")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_text_with_pypdf(file_path: str) -> list:
    reader = PdfReader(file_path)
    pages = []
    for page in reader.pages:
        try:
            text = page.extract_text()
        except Exception:
            text = ""
        pages.append(normalize_text(text))
    return pages


def extract_text_with_pymupdf(file_path: str) -> list:
    doc = fitz.open(file_path)
    pages = []
    for page in doc:
        try:
            text = page.get_text("text")
        except Exception:
            text = ""
        pages.append(normalize_text(text))
    doc.close()
    return pages


def extract_text_with_pdfplumber(file_path: str) -> list:
    pages = []
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            try:
                text = page.extract_text()
            except Exception:
                text = ""
            pages.append(normalize_text(text))
    return pages


def render_pdf_pages_to_images(file_path: str) -> list:
    doc = fitz.open(file_path)
    output_folder = build_page_images_folder(file_path)
    image_paths = []
    for i, page in enumerate(doc):
        image_path = os.path.join(output_folder, f"page_{i + 1:03d}.png")
        if not os.path.exists(image_path):
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
            pix.save(image_path)
        image_paths.append(image_path)
    doc.close()
    return image_paths


def calc_text_quality_score(text: str) -> float:
    if not text:
        return 0.0

    text_len = len(text)
    chinese_chars = len(re.findall(r"[\u4e00-\u9fff]", text))
    english_chars = len(re.findall(r"[A-Za-z]", text))
    digits = len(re.findall(r"\d", text))
    weird_chars = len(re.findall(r"[�□■◆◇¤�]", text))
    printable_ratio = (chinese_chars + english_chars + digits) / max(text_len, 1)

    score = 0
    score += min(text_len, 4000) / 80
    score += printable_ratio * 60
    score -= weird_chars * 4
    return score


def detect_language(text: str) -> str:
    if not text or len(text.strip()) < 20:
        return "unknown"

    chinese_count = len(re.findall(r"[\u4e00-\u9fff]", text))
    english_count = len(re.findall(r"[A-Za-z]", text))
    trad_markers = len(re.findall(r"[國報業務關聯會計應收資產負債權益營運風險醫療藥務經營審核證券銷售增長發展數據網絡競爭優勢現金損益說明]", text))
    simp_markers = len(re.findall(r"[国报业务关联会计应收资产负债权益营运风险医疗药务经营审核证券销售增长发展数据网络竞争优势现金损益说明]", text))

    if chinese_count > 30 and english_count > 30:
        if trad_markers > simp_markers:
            return "mixed_zh_tw"
        if simp_markers > trad_markers:
            return "mixed_zh_cn"
        return "mixed"

    if english_count > chinese_count * 1.5 and english_count > 80:
        return "en"

    if chinese_count > 30:
        if trad_markers > simp_markers:
            return "zh_tw"
        if simp_markers > trad_markers:
            return "zh_cn"
        return "zh"

    return "unknown"


def classify_page_type(text: str) -> str:
    if not text or len(text.strip()) < 30:
        return "scanned_or_image"

    text_len = len(text)
    line_count = max(len(text.splitlines()), 1)
    digits = len(re.findall(r"\d", text))
    chinese_chars = len(re.findall(r"[\u4e00-\u9fff]", text))
    english_chars = len(re.findall(r"[A-Za-z]", text))
    weird_chars = len(re.findall(r"[�□■◆◇¤�]", text))
    percent_count = text.count("%")
    currency_count = len(re.findall(r"[¥￥$€港元人民币人民幣元亿元萬元万亿]", text))
    table_like_separators = len(re.findall(r"[\t|]{1,}", text))
    avg_line_len = text_len / line_count
    readable_ratio = (digits + chinese_chars + english_chars) / max(text_len, 1)

    if digits > 40 and (percent_count > 3 or currency_count > 3 or table_like_separators > 2):
        return "table_like"
    if weird_chars > 5 or readable_ratio < 0.35:
        return "text_bad"
    if digits > 20 and avg_line_len < 25:
        return "mixed_layout"
    return "text_good"


def choose_best_page_text(page_text_candidates: dict) -> tuple:
    scored = {engine_name: calc_text_quality_score(text) for engine_name, text in page_text_candidates.items()}
    best_engine = max(scored, key=scored.get)
    return best_engine, page_text_candidates[best_engine], scored


def parse_page_with_text_engine(best_text: str, language: str, engine_name: str) -> dict:
    return {
        "engine": engine_name,
        "provider": "local_text",
        "ai_called": False,
        "text": best_text,
        "language": language,
        "raw_markdown": "",
        "table_blocks": [],
        "image_blocks": [],
        "notes": "当前页使用传统文本提取引擎。",
    }


def route_page_parser(page_type: str, image_path: str, best_text: str, language: str, best_engine: str, page_number: int) -> dict:
    if page_type == "text_good":
        return parse_page_with_text_engine(best_text=best_text, language=language, engine_name=best_engine)

    mm_result = parse_page_with_multimodal_stub(image_path=image_path, fallback_text=best_text, page_number=page_number)
    return {
        "engine": mm_result["engine"],
        "provider": mm_result.get("provider", "stub"),
        "ai_called": mm_result.get("ai_called", False),
        "text": mm_result["text"],
        "language": language,
        "raw_markdown": mm_result.get("raw_markdown", ""),
        "table_blocks": mm_result.get("table_blocks", []),
        "image_blocks": mm_result.get("image_blocks", []),
        "notes": mm_result.get("notes", ""),
    }


def extract_best_text_from_pdf(file_path: str) -> dict:
    pypdf_pages = extract_text_with_pypdf(file_path)
    pymupdf_pages = extract_text_with_pymupdf(file_path)
    pdfplumber_pages = extract_text_with_pdfplumber(file_path)
    image_paths = render_pdf_pages_to_images(file_path)

    page_count = max(len(pypdf_pages), len(pymupdf_pages), len(pdfplumber_pages), len(image_paths))
    pages_data = []
    full_text_parts = []
    engine_counter = Counter()
    page_type_counter = Counter()

    for i in range(page_count):
        candidates = {
            "pypdf": pypdf_pages[i] if i < len(pypdf_pages) else "",
            "pymupdf": pymupdf_pages[i] if i < len(pymupdf_pages) else "",
            "pdfplumber": pdfplumber_pages[i] if i < len(pdfplumber_pages) else "",
        }
        image_path = image_paths[i] if i < len(image_paths) else ""
        best_engine, best_text, score_map = choose_best_page_text(candidates)
        page_language = detect_language(best_text)
        page_type = classify_page_type(best_text)
        parsed_page = route_page_parser(page_type=page_type, image_path=image_path, best_text=best_text, language=page_language, best_engine=best_engine, page_number=i + 1)

        engine_counter[parsed_page["engine"]] += 1
        page_type_counter[page_type] += 1

        page_record = {
            "page_number": i + 1,
            "page_image_path": image_path,
            "page_type": page_type,
            "language": parsed_page["language"],
            "engine": parsed_page["engine"],
            "provider": parsed_page.get("provider", ""),
            "ai_called": parsed_page.get("ai_called", False),
            "scores": score_map,
            "text": parsed_page["text"],
            "raw_markdown": parsed_page["raw_markdown"],
            "table_blocks": parsed_page["table_blocks"],
            "image_blocks": parsed_page["image_blocks"],
            "notes": parsed_page["notes"],
        }
        pages_data.append(page_record)
        if parsed_page["text"]:
            full_text_parts.append(parsed_page["text"])

    full_text = "\n\n".join(full_text_parts)
    dominant_language = detect_language(full_text)
    complex_page_count = int(page_type_counter.get("table_like", 0) + page_type_counter.get("mixed_layout", 0) + page_type_counter.get("text_bad", 0) + page_type_counter.get("scanned_or_image", 0))
    return {
        "page_count": page_count,
        "full_text": full_text,
        "pages": pages_data,
        "engine_summary": dict(engine_counter),
        "page_type_summary": dict(page_type_counter),
        "multimodal_runtime": {
            "mode": "stub_only",
            "cloud_llm_called": False,
            "complex_page_count": complex_page_count,
            "notes": "复杂页当前仅保留图片并走 multimodal_stub，不会调用阿里云或 DeepSeek。",
        },
        "dominant_language": dominant_language,
    }


def build_parsed_output(company_name: str, file_path: str) -> dict:
    parsed_result = extract_best_text_from_pdf(file_path)
    source_file = os.path.basename(file_path)
    full_text = parsed_result["full_text"]
    period_meta = build_period_metadata(source_file=source_file, text=full_text)
    return {
        "company_name": company_name,
        "source_file": source_file,
        "file_path": file_path,
        "page_count": parsed_result["page_count"],
        "dominant_language": parsed_result["dominant_language"],
        "engine_summary": parsed_result["engine_summary"],
        "page_type_summary": parsed_result["page_type_summary"],
        "multimodal_runtime": parsed_result["multimodal_runtime"],
        "fiscal_year": period_meta["fiscal_year"],
        "report_type": period_meta["report_type"],
        "period_key": period_meta["period_key"],
        "report_date": period_meta["report_date"],
        "is_annual_final": period_meta["is_annual_final"],
        "full_text": full_text,
        "pages": parsed_result["pages"],
    }


def save_parsed_json(parsed_data: dict, output_path: str) -> None:
    output_folder = os.path.dirname(output_path)
    os.makedirs(output_folder, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(parsed_data, f, ensure_ascii=False, indent=2)
