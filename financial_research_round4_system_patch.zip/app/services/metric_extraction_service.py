import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from config.settings import SCHEMA_VERSION
from services.metric_table_service import extract_table_metric_candidates, merge_metric_candidates
from services.period_service import period_sort_tuple
from services.research_utils import now_iso
from utils.file_utils import (
    build_metric_registry_path,
    get_extracted_json_files_in_company_folder,
    get_parsed_json_files_in_company_folder,
    load_json_file,
    save_json_file,
    sort_paths_by_year_and_name,
)

STANDARD_METRIC_ALIASES = {
    "revenue": ["revenue", "revenues", "营业收入", "收入", "收益", "營業收入", "收益總額"],
    "gross_profit": ["gross profit", "毛利", "毛利润", "毛利潤"],
    "gross_margin": ["gross margin", "gross profit margin", "毛利率", "整體毛利率"],
    "operating_profit": ["operating profit", "operating income", "营业利润", "經營溢利", "营业收益"],
    "operating_margin": ["operating margin", "营业利润率", "经营利润率", "經營利潤率"],
    "net_profit": ["net profit", "profit attributable", "profit attributable to owners", "归母净利润", "净利润", "本公司拥有人应占利润", "母公司拥有人应占利润", "本公司權益股東應佔溢利", "淨利潤"],
    "adjusted_net_profit": ["adjusted net profit", "non-ifrs net profit", "经调整净利润", "非国际财务报告准则净利润", "经调整纯利"],
    "ebitda": ["ebitda", "息税折旧摊销前利润", "經調整ebitda"],
    "ebitda_margin": ["ebitda margin", "ebitda率", "息税折旧摊销前利润率"],
    "operating_cash_flow": ["operating cash flow", "cash generated from operating activities", "net cash generated from operating activities", "经营活动现金流", "经营现金流", "經營活動所得現金流量淨額", "经营活动产生的现金流量净额"],
    "free_cash_flow": ["free cash flow", "自由现金流", "自由現金流"],
    "capex": ["capex", "capital expenditure", "资本开支", "資本開支"],
    "cash_and_equivalents": ["cash and cash equivalents", "现金及现金等价物", "現金及現金等價物", "cash balance"],
    "total_debt": ["total debt", "borrowings", "有息负债", "借款总额", "借款總額"],
    "net_cash": ["net cash", "net debt", "净现金", "淨現金", "净负债", "淨負債"],
    "accounts_receivable": ["accounts receivable", "trade receivables", "应收账款", "應收賬款", "贸易应收款"],
    "inventory": ["inventory", "inventories", "存货", "存貨"],
    "contract_liabilities": ["contract liabilities", "合同负债", "合約負債"],
    "order_backlog": ["backlog", "order backlog", "在手订单", "未完成订单", "未完成合約"],
    "r_and_d_expense": ["r&d expense", "research and development expenses", "研发费用", "研發開支", "研究及开发开支"],
    "selling_expense": ["selling expense", "sales and marketing expense", "销售费用", "銷售費用", "销售及分销开支"],
    "admin_expense": ["administrative expense", "general and administrative expense", "管理费用", "行政開支"],
    "customer_count": ["customer count", "active customers", "客户数", "活跃客户数", "活躍客戶數"],
    "arpu": ["arpu", "average revenue per user", "每用户平均收入", "每用戶平均收入"],
    "utilization_rate": ["utilization rate", "capacity utilization", "产能利用率", "產能利用率"],
    "production_volume": ["production volume", "产量", "產量"],
    "sales_volume": ["sales volume", "销量", "銷量"],
    "average_selling_price": ["average selling price", "asp", "平均售价", "平均售價"],
}

VALUE_REGEX = re.compile(r"(?P<label>[A-Za-z\u4e00-\u9fff\(\)（）\/\-\s&]{2,80})[:：]?\s*(?P<value>-?\d[\d,]*\.?\d*)\s*(?P<unit>%|亿元|億元|百万元|百萬元|万元|萬元|million|billion|mn|bn)?", re.IGNORECASE)
YOY_REGEX = re.compile(r"(同比|按年|year on year|yoy)[^\d\-+]*([\-+]?\d[\d,]*\.?\d*)\s*%", re.IGNORECASE)


def _safe_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(",", "")
    if not text:
        return None
    try:
        return float(text)
    except Exception:
        return None


def _match_metric_name(label: str) -> Optional[str]:
    label_n = (label or "").strip().lower()
    if not label_n:
        return None
    for metric_name, aliases in STANDARD_METRIC_ALIASES.items():
        for alias in aliases:
            if alias.lower() in label_n:
                return metric_name
    return None


def _build_candidate_base(extracted_data: dict) -> dict:
    is_primary = bool(extracted_data.get("is_primary_financial_report", False))
    return {
        "period_key": extracted_data.get("period_key", ""),
        "related_primary_period_key": extracted_data.get("related_primary_period_key", extracted_data.get("period_key", "")),
        "document_type": extracted_data.get("document_type", "other_disclosure"),
        "timeline_bucket": extracted_data.get("timeline_bucket", "primary" if is_primary else "auxiliary"),
        "material_timestamp": extracted_data.get("material_timestamp", ""),
        "is_primary_financial_report": is_primary,
        "can_adjust_forecast": bool(extracted_data.get("can_adjust_forecast", False)),
        "source_role": "primary_timeline" if is_primary else "auxiliary_signal",
        "allow_into_actuals": is_primary,
    }


def _extract_candidates_from_text(text: str, source_file: str, candidate_base: dict) -> List[dict]:
    text = text or ""
    results = []
    for match in VALUE_REGEX.finditer(text):
        label = (match.group("label") or "").strip()
        value = _safe_float(match.group("value"))
        unit = (match.group("unit") or "").strip()
        metric_name = _match_metric_name(label)
        if metric_name is None or value is None:
            continue
        start = max(0, match.start() - 80)
        end = min(len(text), match.end() + 120)
        snippet = text[start:end].replace("\n", " ").strip()
        yoy_match = YOY_REGEX.search(snippet)
        yoy_value = _safe_float(yoy_match.group(2)) if yoy_match else None
        score = 1.0 + (0.2 if unit else 0) + (0.2 if yoy_value is not None else 0)
        item = {
            "metric_name": metric_name,
            "raw_label": label,
            "value": value,
            "value_base": None,
            "prior_value": None,
            "prior_value_base": None,
            "unit": unit,
            "yoy_percent": yoy_value,
            "qoq_percent": None,
            "snippet": snippet,
            "source_file": source_file,
            "confidence": "medium",
            "extraction_method": "text_scan",
            "score": round(score, 3),
        }
        item.update(candidate_base)
        results.append(item)
    return results


def _deduplicate_candidates(candidates: List[dict]) -> List[dict]:
    seen = set()
    deduped = []
    for item in candidates:
        key = (
            item.get("metric_name", ""),
            item.get("source_file", ""),
            item.get("related_primary_period_key", ""),
            item.get("value"),
            item.get("unit", ""),
            item.get("extraction_method", ""),
        )
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def _build_output_paths(company_folder: str | Path) -> Tuple[Path, Path]:
    company_folder = Path(company_folder)
    analysis_dir = company_folder / "年报分析"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    return analysis_dir / "standardized_metrics.json", analysis_dir / "metric_extraction_registry.json"


def extract_standardized_metrics(company_folder: str | Path) -> dict:
    company_folder = Path(company_folder)
    parsed_files = sort_paths_by_year_and_name(get_parsed_json_files_in_company_folder(company_folder))
    extracted_files = sort_paths_by_year_and_name(get_extracted_json_files_in_company_folder(company_folder))

    extracted_map = {}
    for extracted_path in extracted_files:
        extracted_data = load_json_file(extracted_path)
        extracted_map[extracted_data.get("source_file", "")] = extracted_data

    all_candidates = []
    source_summaries = []
    for parsed_path in parsed_files:
        parsed_data = load_json_file(parsed_path)
        source_file = parsed_data.get("source_file", Path(parsed_path).name)
        extracted_data = extracted_map.get(source_file, {})
        candidate_base = _build_candidate_base(extracted_data)
        full_text = parsed_data.get("full_text", "")

        table_candidates = extract_table_metric_candidates(
            text=full_text,
            source_file=source_file,
            period_key=candidate_base.get("related_primary_period_key", ""),
            material_timestamp=candidate_base.get("material_timestamp", ""),
        )
        for row in table_candidates:
            row.update(candidate_base)

        text_candidates = _extract_candidates_from_text(text=full_text, source_file=source_file, candidate_base=candidate_base)
        candidates = _deduplicate_candidates(merge_metric_candidates(table_candidates, text_candidates))
        all_candidates.extend(candidates)

        source_summaries.append({
            "source_file": source_file,
            "document_type": candidate_base.get("document_type", "other_disclosure"),
            "timeline_bucket": candidate_base.get("timeline_bucket", "auxiliary"),
            "period_key": candidate_base.get("period_key", ""),
            "related_primary_period_key": candidate_base.get("related_primary_period_key", ""),
            "material_timestamp": candidate_base.get("material_timestamp", ""),
            "table_candidate_count": len(table_candidates),
            "text_candidate_count": len(text_candidates),
            "merged_candidate_count": len(candidates),
        })

    metric_groups: Dict[str, List[dict]] = {}
    for item in all_candidates:
        metric_groups.setdefault(item.get("metric_name", ""), []).append(item)

    for metric_name, rows in metric_groups.items():
        rows.sort(
            key=lambda x: (
                period_sort_tuple(x.get("related_primary_period_key", "")),
                1 if x.get("is_primary_financial_report") else 0,
                x.get("score", 0),
                x.get("material_timestamp", ""),
            ),
            reverse=True,
        )

    standardized_output = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": now_iso(),
        "company_name": company_folder.name,
        "metrics": metric_groups,
    }
    extraction_registry = {
        "schema_version": SCHEMA_VERSION,
        "generated_at": now_iso(),
        "company_name": company_folder.name,
        "source_summaries": source_summaries,
        "total_candidate_count": len(all_candidates),
        "metric_names": sorted(list(metric_groups.keys())),
    }

    standardized_path, registry_path = _build_output_paths(company_folder)
    save_json_file(standardized_output, standardized_path)
    save_json_file(extraction_registry, registry_path)
    return {
        "status": "ok",
        "company_name": company_folder.name,
        "standardized_metrics_path": str(standardized_path),
        "metric_extraction_registry_path": str(registry_path),
        "metric_names": sorted(list(metric_groups.keys())),
        "total_candidate_count": len(all_candidates),
        "metrics": metric_groups,
    }


def load_standardized_metrics(company_folder: str | Path) -> dict:
    standardized_path, _ = _build_output_paths(company_folder)
    if standardized_path.exists():
        return load_json_file(standardized_path)
    return {"schema_version": SCHEMA_VERSION, "generated_at": "", "company_name": Path(company_folder).name, "metrics": {}}


def merge_selected_metrics_to_registry(company_folder: str | Path, selections: Dict[str, List[dict]]) -> dict:
    company_folder = Path(company_folder)
    registry_path = Path(build_metric_registry_path(company_folder))
    if registry_path.exists():
        metric_registry = load_json_file(registry_path)
    else:
        metric_registry = {
            "schema_version": SCHEMA_VERSION,
            "generated_at": now_iso(),
            "company_name": company_folder.name,
            "primary_timeline": [],
            "metrics": list(STANDARD_METRIC_ALIASES.keys()),
            "metric_values": {},
        }
    metric_registry.setdefault("metric_values", {})
    for metric_name, rows in selections.items():
        primary_only_rows = [row for row in rows if row.get("allow_into_actuals", True) or row.get("source_role") == "primary_timeline"]
        metric_registry["metric_values"][metric_name] = primary_only_rows
    metric_registry["generated_at"] = now_iso()
    save_json_file(metric_registry, registry_path)
    return {"status": "ok", "metric_registry_path": str(registry_path), "updated_metrics": sorted(list(selections.keys()))}
