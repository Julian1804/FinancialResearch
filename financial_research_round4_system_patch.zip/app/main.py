import streamlit as st

st.set_page_config(page_title="Financial Research Assistant", page_icon="📊", layout="wide")

st.title("📊 Financial Research Assistant")
st.write("欢迎来到财报研究助手。")

st.markdown("## 建议测试顺序")
cols = st.columns(4)
with cols[0]:
    st.page_link("pages/upload.py", label="1. Upload")
    st.page_link("pages/ingest.py", label="2. Ingest（推荐）")
    st.page_link("pages/parse.py", label="3. Parse")
    st.page_link("pages/extract.py", label="4. Extract")
with cols[1]:
    st.page_link("pages/metrics.py", label="5. Metrics")
    st.page_link("pages/metrics_table.py", label="6. Metrics Table")
    st.page_link("pages/actuals.py", label="7. Actuals")
    st.page_link("pages/analyze.py", label="8. Analyze")
with cols[2]:
    st.page_link("pages/update.py", label="9. Update")
    st.page_link("pages/forecast.py", label="10. Forecast")
    st.page_link("pages/forecast_check.py", label="11. Forecast Check")
    st.page_link("pages/backtest_report.py", label="12. Backtest Report")
with cols[3]:
    st.page_link("pages/master_report.py", label="13. Master Report")
    st.page_link("pages/summary_report.py", label="14. Summary Report")
    st.page_link("pages/decision_support.py", label="15. Decision Support")
    st.page_link("pages/qa.py", label="16. QA")

st.markdown("""
### 当前系统定位
这不是一次性生成报告的聊天工具，而是一个**持续研究、持续修正预期、持续回测偏差**的研究系统。

### 本轮特别提醒
- `_system` 已不应再出现在公司下拉框
- Parse 里的复杂页当前还是 **multimodal_stub**，不会调用云端 AI
- 日常主流程建议优先使用 **Ingest 页面**，保留 Parse / Extract / Metrics 单页用于排错
- 辅助材料会保留在研究上下文中，但**不能进入 actuals 主表，也不能污染主时序硬数值**
""")
