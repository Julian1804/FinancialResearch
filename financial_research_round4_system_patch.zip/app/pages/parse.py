import sys
from pathlib import Path

import streamlit as st

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

from services.company_ui_service import format_company_option, get_company_folder_path, get_company_select_values
from services.ingest_service import run_ingest_pipeline
from utils.file_utils import build_parsed_json_path, get_pdf_files_in_company_folder, load_json_file


def parse_financial_report_page():
    st.title("财报解析（多引擎 + 多模态预留）")
    st.info("说明：复杂页当前仅走 multimodal_stub，占位保留页面图片，不会调用阿里云或 DeepSeek。因此你在阿里云流量监控里看不到 Parse 阶段记录，是正常现象。")

    company_values = get_company_select_values()
    if len(company_values) <= 1:
        st.warning("还没有任何公司文件夹，请先上传财报。")
        return

    selected_company = st.selectbox("请选择公司", options=company_values, index=0, format_func=format_company_option)
    if not selected_company:
        st.info("请先选择公司。")
        return

    company_folder = get_company_folder_path(selected_company)
    pdf_files = get_pdf_files_in_company_folder(company_folder)
    if not pdf_files:
        st.warning("该公司“年报”文件夹下没有 PDF 文件。")
        return

    pdf_options = [Path(path).name for path in pdf_files]
    selected_pdf_name = st.selectbox("请选择要解析的文件", options=[""] + pdf_options, index=0)
    if not selected_pdf_name:
        st.info("请先选择 PDF 文件。")
        return

    selected_pdf_path = next(path for path in pdf_files if Path(path).name == selected_pdf_name)
    parsed_json_path = Path(build_parsed_json_path(selected_pdf_path))
    parsed_exists = parsed_json_path.exists()

    if parsed_exists:
        parsed_preview = load_json_file(parsed_json_path)
        st.warning(f"已存在解析文件：{parsed_json_path.name}")
        st.json({
            "source_file": parsed_preview.get("source_file", ""),
            "page_count": parsed_preview.get("page_count", 0),
            "dominant_language": parsed_preview.get("dominant_language", ""),
            "engine_summary": parsed_preview.get("engine_summary", {}),
            "page_type_summary": parsed_preview.get("page_type_summary", {}),
            "multimodal_runtime": parsed_preview.get("multimodal_runtime", {}),
        })

    auto_extract = st.checkbox("解析完成后自动执行 Extract", value=True)
    auto_metrics = st.checkbox("Extract 完成后自动刷新 Metrics", value=True, disabled=not auto_extract)
    confirm_overwrite = st.checkbox("我确认：如果已存在 parsed JSON，则覆盖原文件", value=not parsed_exists)

    if st.button("开始解析 / 一体化入库", disabled=(parsed_exists and not confirm_overwrite)):
        with st.spinner("正在执行 Parse → Extract → Metrics，请稍候..."):
            result = run_ingest_pipeline(
                company_name=selected_company,
                pdf_path=selected_pdf_path,
                run_extract=auto_extract,
                run_metrics=auto_metrics,
            )

        parsed_data = result["parsed_data"]
        st.success("处理完成！")
        st.write(f"解析结果已保存到：{result['parsed_path']}")
        if result.get("extracted_path"):
            st.write(f"提取结果已保存到：{result['extracted_path']}")
        st.write(f"页数：{parsed_data['page_count']}")
        st.write(f"全文字符数：{len(parsed_data['full_text'])}")
        st.write(f"全文主语言：{parsed_data['dominant_language']}")
        st.write(f"解析引擎统计：{parsed_data['engine_summary']}")
        st.write(f"页面类型统计：{parsed_data['page_type_summary']}")
        st.write(f"多模态运行状态：{parsed_data.get('multimodal_runtime', {})}")
        metrics_result = result.get("metrics_result") or {}
        if metrics_result:
            st.write(f"本次刷新后的指标数：{len(metrics_result.get('metric_names', []))}")
        st.subheader("全文预览（前 3000 字符）")
        st.text_area("解析结果预览", parsed_data["full_text"][:3000], height=350)


if __name__ == "__main__":
    parse_financial_report_page()
