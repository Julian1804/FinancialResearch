import sys
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.append(str(ROOT_DIR))

from services.company_ui_service import format_company_option, get_company_folder_path, get_company_select_values
from services.metric_extraction_service import extract_standardized_metrics, load_standardized_metrics, merge_selected_metrics_to_registry
from services.repository_service import refresh_company_repository


def _build_default_selection_rows(candidates: list) -> list:
    best_by_period = {}
    for item in candidates:
        if not item.get("allow_into_actuals", item.get("is_primary_financial_report", False)):
            continue
        period_key = item.get("related_primary_period_key") or item.get("period_key", "")
        if not period_key:
            continue
        current = best_by_period.get(period_key)
        if current is None or item.get("score", 0) > current.get("score", 0):
            row = dict(item)
            row["period_key"] = period_key
            best_by_period[period_key] = row
    return [best_by_period[k] for k in sorted(best_by_period.keys())]


def metrics_page():
    st.title("标准化财务指标抽取")
    st.caption("本页会保留辅助材料候选，但 actuals 与主时序写回默认只接纳 primary_timeline。")

    company_values = get_company_select_values()
    if len(company_values) <= 1:
        st.warning("还没有任何公司文件夹。")
        return

    selected_company = st.selectbox("请选择公司", options=company_values, index=0, format_func=format_company_option)
    if not selected_company:
        st.info("请先选择公司。")
        return

    company_folder = get_company_folder_path(selected_company)

    col1, col2 = st.columns(2)
    with col1:
        if st.button("执行自动指标抽取"):
            with st.spinner("正在扫描 parsed / extracted 并生成标准化指标候选..."):
                result = extract_standardized_metrics(company_folder)
                refresh_company_repository(company_folder)
            st.success(f"抽取完成：候选数={result.get('total_candidate_count', 0)}，指标数={len(result.get('metric_names', []))}")
    with col2:
        if st.button("重新读取抽取结果"):
            st.rerun()

    extracted_data = load_standardized_metrics(company_folder)
    metrics = extracted_data.get("metrics", {})
    if not metrics:
        st.info("当前还没有标准化指标结果。请先点击“执行自动指标抽取”。")
        return

    metric_names = sorted(list(metrics.keys()))
    selected_metric = st.selectbox("请选择标准化指标", options=metric_names, index=0)
    candidates = metrics.get(selected_metric, [])
    if not candidates:
        st.info("当前指标没有候选值。")
        return

    st.markdown("## 自动抽取候选")
    candidate_rows = []
    for idx, item in enumerate(candidates, start=1):
        candidate_rows.append({
            "candidate_id": idx,
            "metric_name": item.get("metric_name", ""),
            "related_primary_period_key": item.get("related_primary_period_key", item.get("period_key", "")),
            "document_type": item.get("document_type", ""),
            "source_role": item.get("source_role", ""),
            "value": item.get("value"),
            "unit": item.get("unit", ""),
            "yoy_percent": item.get("yoy_percent"),
            "score": item.get("score"),
            "source_file": item.get("source_file", ""),
            "material_timestamp": item.get("material_timestamp", ""),
            "raw_label": item.get("raw_label", ""),
            "snippet": item.get("snippet", ""),
        })
    st.dataframe(pd.DataFrame(candidate_rows), width="stretch")

    st.markdown("## 默认写回表（仅主时序）")
    recommended_rows = _build_default_selection_rows(candidates)
    rec_df = pd.DataFrame(recommended_rows)
    if rec_df.empty:
        st.info("当前没有可写回主时序的 period 数据。这通常意味着当前候选主要来自辅助材料。")
        return

    edited_df = st.data_editor(
        rec_df,
        width="stretch",
        num_rows="dynamic",
        hide_index=True,
        column_config={
            "period_key": st.column_config.TextColumn("period_key"),
            "document_type": st.column_config.TextColumn("document_type"),
            "source_role": st.column_config.TextColumn("source_role"),
            "source_file": st.column_config.TextColumn("source_file"),
            "material_timestamp": st.column_config.TextColumn("material_timestamp"),
            "value": st.column_config.NumberColumn("value"),
            "unit": st.column_config.TextColumn("unit"),
        },
    )

    if st.button("写回 metric_series_registry.json（主时序）"):
        rows = edited_df.to_dict(orient="records")
        payload = merge_selected_metrics_to_registry(company_folder=company_folder, selections={selected_metric: rows})
        st.success(f"已写回指标：{selected_metric}")
        st.json(payload)


if __name__ == "__main__":
    metrics_page()
